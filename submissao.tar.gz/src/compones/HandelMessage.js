import { useState, useEffect } from 'react';

const useMessaging = () => {
  const [conversations, setConversations] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    const webSocket = new WebSocket('url');

    webSocket.onopen = () => {
      console.log('WebSocket connection established');
    };

    webSocket.onmessage = (event) => {
      const message = JSON.parse(event.data);
      setConversations((prev) => [...prev, message]);
    };

    webSocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    webSocket.onclose = () => {
      console.log('WebSocket connection closed');
    };

    setSocket(webSocket);

    return () => {
      webSocket.close();
    };
  }, []);

  const handleMessageChange = (event) => {
    setCurrentMessage(event.target.value);
  };

  const sendMessage = (currentUser) => {
    if (currentMessage.trim() === '' && !audioBlob && !uploadedFile) return;

    const newMessage = {
      content: currentMessage,
      status: 'pending',
      file: audioBlob || uploadedFile,
      sender: currentUser,
      timestamp: new Date().toISOString(),
    };

    setConversations((prev) => [...prev, newMessage]);
    socket.send(JSON.stringify(newMessage));

    setCurrentMessage('');
    setAudioBlob(null);
    setUploadedFile(null);
    setFilePreview(null);
  };

  const startRecording = async () => {
    setIsRecording(true);
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);

    recorder.ondataavailable = (event) => {
      setAudioBlob(event.data);
    };

    recorder.start();
    setMediaRecorder(recorder);
  };

  const stopRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.stop();
      setIsRecording(false);
      setMediaRecorder(null);
    }
  };

  const uploadFile = (event) => {
    const selectedFile = event.target.files[0];
    setUploadedFile(selectedFile);

    if (selectedFile) {
      setFilePreview(URL.createObjectURL(selectedFile));
    }
  };

  return {
    conversations,
    currentMessage,
    isRecording,
    audioBlob,
    uploadedFile,
    filePreview,
    handleMessageChange,
    sendMessage,
    startRecording,
    stopRecording,
    uploadFile,
  };
};

export default useMessaging;