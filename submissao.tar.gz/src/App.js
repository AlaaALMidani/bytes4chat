import './index.css';

import MessagingApp from './MessageHandel';
import Home from './Home'
import ChatApp from './Chat';
function App() {
  return (
    <div className="App">
      {/* <Home/> */}
   <MessagingApp/>
   {/* <ChatApp/> */}
    </div>
  );
}

export default App;
